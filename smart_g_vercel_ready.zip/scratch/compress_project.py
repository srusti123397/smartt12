import os
import zipfile

def compress_project():
    # Root directory of our project
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    zip_name = os.path.join(root_dir, "smart_g_vercel_ready.zip")
    
    exclude_dirs = {
        'node_modules', 'dist', 'data', '.git', '.vscode', 
        'backend-node', 'backend-python', '__pycache__', '.pytest_cache'
    }
    exclude_files = {
        '.env', 'smart_g_vercel_ready.zip'
    }
    
    print(f"Starting compression of workspace: {root_dir}...")
    count = 0
    
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(root_dir):
            # Exclude specified directories from walking
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                # Exclude specified files
                if file in exclude_files:
                    continue
                if file.endswith('.zip') or file.endswith('.rar'):
                    continue
                    
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, root_dir)
                
                zipf.write(full_path, rel_path)
                count += 1
                
    print(f"Successfully compressed {count} files into '{os.path.basename(zip_name)}'!")

if __name__ == '__main__':
    compress_project()
